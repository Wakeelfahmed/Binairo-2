#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGridLayout>


#include"gameboard.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void Select_Starting_Method();
    void createTopLayout(QVBoxLayout *);
    void createGridLayout(QVBoxLayout *mainLayout);
    void clearGridLayout();
    void createInterface();
    void setBackgroundColor(const QColor &color);
private:
    GameBoard board;
    Ui::MainWindow *ui;
    QGridLayout *gridLayout;
    void storeOriginalPalette();
    void restoreOriginalPalette();
    QPalette originalPalette;       //store the orginal color for restoration

private slots:
    void onRadioButtonClicked();
    void onPauseButtonClicked();
    void onResetButtonClicked();
    void handleButtonClick();

};
#endif // MAINWINDOW_H
